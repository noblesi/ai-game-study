# Baseline Eval (20251231)

## Data
- train: `datasets/train_experiments_v1.csv`
- test: `datasets/test_scenarios_v1.csv`
- train rows: 1600
- test rows: 39
- train pos_rate: 0.0638
- test pos_rate: 0.4615
- overlap groups: 0 (dropped train rows=0)

## Split
- split_mode: group (train->val only)
- group_key: pair_key_full
- group_stratified: True (tries=300)
- val_ratio: 0.2
- repeats: 30 (seed_base=42)

## Model
- kind: rf
- class_weight: balanced
- rf_grid: True (candidates=12)
- final_params: {"max_depth": null, "max_features": "sqrt", "min_samples_leaf": 1, "min_samples_split": 10, "n_estimators": 400}
- tune_threshold: True (metric=recall)
- final_model: BEST

### Metrics / TEST (over repeats)
- acc       mean=0.6350 min=0.5641 max=0.8462
- bal_acc   mean=0.6107 min=0.5278 max=0.8571
- f1_1      mean=0.3633 min=0.1053 max=0.8571
- recall_1  mean=0.2944 min=0.0556 max=1.0000
- prec_1    mean=0.8842 min=0.6071 max=1.0000
- ap        mean=0.7616 min=0.6119 max=0.9190
- roc_auc   mean=0.7968 min=0.6283 max=0.9392
- thr       mean=0.0957 min=0.0500 max=0.2600

### Final Model (fit on FULL train)
- thr: 0.0800
- thr_repeats_mean: 0.0957
- thr_repeats_median: 0.0800
- test metrics:
  - acc: 0.6154
  - bal_acc: 0.5873
  - f1_1: 0.3478
  - recall_1: 0.2222
  - prec_1: 0.8000
  - ap: 0.6887
  - roc_auc: 0.7209

## Features
- num_features: 42
- feature_cols: start_distance, defender_count, a_level, a_hp, a_atk, a_cost, a_range, a_attack_speed, a_move_speed, a_hp_per_level, a_atk_per_level, d_level, d_hp, d_atk, d_cost, d_range, d_attack_speed, d_move_speed, d_hp_per_level, d_atk_per_level, a_perk_count, d_perk_count, a_has_perk_armor, a_has_perk_cleave, a_has_perk_duelist, a_has_perk_execute, a_has_perk_fury, a_has_perk_haste, a_has_perk_lifesteal, a_has_perk_longshot ...
